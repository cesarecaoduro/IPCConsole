﻿using System;
using System.Collections.Generic;
using ZetaIpc.Runtime.Client;
using ZetaIpc.Runtime.Server;

namespace IPCConsole
{
    public class Client
    {
        public string clientName;
        IpcClient cli=null;
        IpcServer srv = null;
        int srvPort;
        public int clientPort;

        public Client(string name, int serverPort, int clientPort=0 )
        {
            clientName = name;
            this.clientPort = clientPort;
            srvPort = serverPort;
            Start();
        }

        public void Start()
        {
            cli = new IpcClient();
            srv = new IpcServer();
            cli.Initialize(srvPort);
            if (clientPort > 0)
            {
                srv.Start(clientPort);
                srv.ReceivedRequest += ReceivedMessage;
            }
        }

        public void Stop()
        {
            srv.Stop();
            srv = null;
            cli = null;
        }

        private void ReceivedMessage(object sender, ReceivedRequestEventArgs args)
        {
            Console.WriteLine(string.Format("client {0} received: {1}", clientName, args.Request));
            args.Handled = true;
        }
        
        public string Send(Event evt)
        {
           
            evt.clientName = this.clientName;
            evt.clientPort = this.clientPort;
            string json = evt.ToJson();
            Console.WriteLine(string.Format("client {0} sent: {1}", clientName, json));
            string resp = cli.Send(json);
            return resp;
           
        }

        public void Connect()
        {
            var evt = new Event("connect", new List<object>() { clientPort });
            evt.clientName = this.clientName;
            evt.clientPort = clientPort;
            cli.Send(evt.ToJson());
        }
    }
}
