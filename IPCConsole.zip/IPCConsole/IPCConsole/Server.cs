﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using ZetaIpc.Runtime.Server;

namespace IPCConsole
{
    public class Server
    {
        List<Client> clients;
        IpcServer srv=null;
        int srvPort;
        public Server(int port)
        {
            srvPort = port;
            clients = new List<Client>();
        }

        public void Start()
        {
            //SERVER
            srv = new IpcServer();
            srv.Start(srvPort); // Passing no port selects a free port automatically.

            Console.WriteLine("Started server on port {0}.", srv.Port);

            srv.ReceivedRequest += ReceiveMessage;
            
        }

        public void Stop()
        {
            srv.Stop();
        }

        public void ReceiveMessage(object sender, ReceivedRequestEventArgs message)
        {
            Event evt = Newtonsoft.Json.JsonConvert.DeserializeObject<Event>(message.Request);

            if (evt.eventName == "connect")
            {
                var newcli = new Client(evt.clientName + "proxy", int.Parse(evt.arguments[0].ToString()));
                newcli.Start();
                clients.Add(newcli);
                Console.WriteLine(string.Format("client {0} connected.", evt.clientName));

            }
            else
            {
                Console.WriteLine("server received: " + evt.arguments[0]);
                message.Handled = true;

                List<Client> toRemove = new List<Client>();
                foreach (var cli in this.clients)
                {
                    if (cli.clientPort != evt.clientPort)
                    {
                        try
                        {
                            cli.Send(evt);
                        }
                        catch (System.Net.WebException)
                        {
                            Console.WriteLine(cli.clientName + " disconnected");
                            toRemove.Remove(cli);
                        }
                        
                    }
                }

                foreach (var cli in toRemove)
                {
                    cli.Stop();
                    clients.Remove(cli);
                }
            }


            
        }


    }
}
