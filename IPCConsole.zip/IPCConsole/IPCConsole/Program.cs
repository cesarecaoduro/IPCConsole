﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ZetaIpc.Runtime.Client;
using ZetaIpc.Runtime.Server;


namespace IPCConsole
{
    class Program
    {

        static void test()
        {

            //cli1 init with a name, server port, client port
            Client cli1 = new Client("CLI1", 12345, 12346);
            //cli2 init with a name, server port, client port
            Client cli2 = new Client("CLI2", 12345, 12347);

            //connect cli1 to server
            cli1.Connect();
            //connect cli2 to server
            cli2.Connect();

            //init a "msg" Event 
            Event evt1 = new Event("msg", new List<object>() { "Msg1" });
            //send it to server
            //server will broadcast to connected clients
            cli1.Send(evt1);

            //simulate a client disconnection
            cli1.Stop();

            //same as evt1, this time from cli2
            //this time cli1 is disconnected, so Server will get an exception while forwarding the message
            //then will remove disconnected client from list of connected client
            //so next messages will no more be sent to cli1
            Event evt2 = new Event("msg", new List<object>() { "Msg2" });
            cli2.Send(evt2);

            
        }

        static void Main(string[] argv)
        {
            //init server with a port number 
            Server srv = new Server(12345);
            //start server listening
            srv.Start();

            //test routing, comment it to use just the server running in a console application
            //test();


            Console.ReadLine();

        }
    }
}
