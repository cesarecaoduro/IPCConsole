﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace IPCConsole
{
    public class Event
    {

        public string eventName;
        public int clientPort;
        public List<object> arguments;
        public string clientName;
        
        public Event(string eventName, List<object> args )
        {
            this.eventName = eventName;
            this.arguments = args;

        }

        public string ToJson()
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(this);

        }
    }
}
